<section>
        <div class="container">
            <!-- <div class="insight-trial"> -->

            <div class="insights">
                <div>
                    <div class="insight-heading">
                        <h3>Insights</h3>
                    </div>
                    <div class="insights-details">
                        <div><img src="images/checkmark.png" alt=""></div>
                        <div class="all-insights">
                            <div>
                                <h5>The Importance of Guarantor <br> Validation Check</h5>
                            </div>
                            <div> <span>March 22, 2021</span></div>
                        </div>
                    </div>

                    <div class="insights-details">
                        <div><img src="images/w-pen.png" alt=""></div>
                        <div class="all-insights">
                            <div>
                                <h5>The Importance of Guarantor <br> Validation Check</h5>
                            </div>
                            <div> <span>March 22, 2021</span></div>
                        </div>
                    </div>

                    <div class="insights-details">
                        <div><img src="images/modern.png" alt=""></div>
                        <div class="all-insights">
                            <div>
                                <h5>The Importance of Guarantor <br> Validation Check</h5>
                            </div>
                            <div> <span>March 22, 2021</span></div>
                        </div>
                    </div>
                </div>

                <div class="insight-img">
                    <img src="images/insights1.png" alt="">
                </div>
            </div>
            <!-- </div> -->
        </div>
    </section>