<section>
        <div class="container">
            <!-- <div class="insight-trial"> -->

            <div class="insights">
                <div>
                    <div class="insight-heading">
                        <h3>Insights</h3>
                    </div>
                    <div class="insights-details">
                        <div><img src="images/checkmark.png" alt=""></div>
                        <div class="all-insights">
                            <div>
                                <h5> <a href="https://klinsheet.com/blog/index.php/2021/03/22/importance-guarantor-validation-checks/" target="_blank" class="insight-link">The Importance of Guarantor <br> Validation Check</a> </h5>
                            </div>
                            <div> <span>March 22, 2021</span></div>
                        </div>
                    </div>

                    <div class="insights-details">
                        <div><img src="images/w-pen.png" alt=""></div>
                        <div class="all-insights">
                            <div>
                                <h5> <a href="https://klinsheet.com/blog/index.php/2021/03/22/importance-guarantor-validation-checks/" target="_blank" class="insight-link">The Importance of Guarantor <br> Validation Check</a> </h5>
                            </div>
                            <div> <span>March 22, 2021</span></div>
                        </div>
                    </div>

                    <div class="insights-details">
                        <div><img src="images/modern.png" alt=""></div>
                        <div class="all-insights">
                            <div>
                                <h5> <a href="https://klinsheet.com/blog/index.php/2021/02/17/right-job-application-form/" target="_blank" class="insight-link">The Importance of Guarantor <br> Validation Check</a> </h5>
                            </div>
                            <div> <span>March 22, 2021</span></div>
                        </div>
                    </div>
                </div>

                <div class="insight-img">
                    <img src="images/insights1.png" alt="">
                </div>
            </div>
            <!-- </div> -->
        </div>
    </section>